﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class RestoreVoucherTransaction : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection();
    DataTable dataTable = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Login"] != null)
        {
            con.ConnectionString = ConfigurationManager.ConnectionStrings["cn"].ConnectionString;
            if (con.State == ConnectionState.Closed)
                con.Open();
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }

    protected string GetTypeName(int id)
    {
        if (id == 3)
            return "Contra";
        else if (id == 4)
            return "Payment";
        else if (id == 5)
            return "Receipt";
        else if (id == 6)
            return "Journal";
        else if (id == 29)
            return "Rectification Entry";
        else
            return "";
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        
       GetVoucherDetails();

    }

    private void GetVoucherDetails()
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "DisplayVoucherDetails";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.Parameters.Add("@InstId", SqlDbType.Int).Value = !string.IsNullOrEmpty(txtInstitutionId.Text)? Convert.ToInt32(txtInstitutionId.Text) : 0;
        SqlDataReader dr = cmd.ExecuteReader();

        dataTable.Columns.Add("TransactionMasterId");
        dataTable.Columns.Add("Institution Id");
        dataTable.Columns.Add("Voucher Type");
        dataTable.Columns.Add("Voucher No");
        dataTable.Columns.Add("Transaction Date");

        while (dr.Read())
        {
            DataRow row = dataTable.NewRow();
            row["TransactionMasterId"] = dr["TransactionMasterId"];
            string voucherType = GetTypeName(Convert.ToInt32(dr["VoucherTypeId"]));
            row["Institution Id"] = dr["InstId"];
            row["Voucher Type"] = voucherType;
            row["Voucher No"] = dr["VoucherNo"];
            row["Transaction Date"] = dr["TransactionDate"];
            dataTable.Rows.Add(row);
            // txtTransactionDate.Text = dt.ToShortDateString();
        }
        if (!dr.HasRows)
        { 
            lblMessage.Text = "No Record Found";
            //txtInstitutionId.Text=string.Empty;
        }
        else
            lblMessage.Text = string.Empty;
        grdVoucherDetails.DataSource = dataTable;

        grdVoucherDetails.DataBind();
        dr.Close();
        cmd.Dispose();
       // grdVoucherDetails.Columns[0].Visible=false;
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Remove("Login");
        Response.Redirect("Login.aspx");
    }

    protected void grdVoucherDetails_SelectedIndexChanged(object sender, EventArgs e)
    {

        
    }

    protected void grdVoucherDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        //grdVoucherDetails.Columns[0].Visible = true;
        int transactionMasterId = Convert.ToInt32(grdVoucherDetails.Rows[e.RowIndex].Cells[0].Text);
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "RestoreVoucherTransaction";
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Connection = con;
        cmd.Parameters.Add("@TransactionMasterId", SqlDbType.Int).Value = transactionMasterId;
        cmd.ExecuteNonQuery();
        GetVoucherDetails();
    }
}