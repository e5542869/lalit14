﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (txtUserName.Text == "admin" && txtPassword.Text == "admin")
        {
            //FormsAuthentication.RedirectFromLoginPage(txtUserName.Text, false);
            Session["Login"] = true;
            Response.Redirect("VoucherDetails.aspx");

        }
        else if (txtUserName.Text == "admin1" && txtPassword.Text == "admin1")
        {
            Session["Login"] = true;
            Response.Redirect("RestoreVoucherTransaction.aspx");
        }
        else
        {
            Response.Write("Wrong user/pwd");
        }
    }
}